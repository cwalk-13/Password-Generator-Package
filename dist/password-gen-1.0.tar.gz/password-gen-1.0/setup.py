from setuptools import setup, find_packages

setup(
    name = 'password-gen',
    version='1.0',
    author='Charles Walker',
    packages=find_packages(),
)